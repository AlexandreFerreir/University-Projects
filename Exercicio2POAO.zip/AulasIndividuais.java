/**
 * @author Alexandre Ferreira
 * @version 1.0
 */

/**
 * Subclasse da classe aula para definir uma aula individual
 */
class AulasIndividuais extends Aula{
    /**
     * Preço por hora da aula individual
     */
    protected double precohora;

    /**
     * Construtor sem parâmetros
     */
    public AulasIndividuais(){}

    /**
     * Construtor da subclasse, recebe dados para a inicialização dos atributos da superclasse e subclasse
     * @param estado Estado da aula individual
     * @param professor Professor da aula individual
     * @param horario Horário da aula individual
     * @param duracao Duração da aula individual
     * @param precohora Preço por hora da aula individual
     */

    public AulasIndividuais(boolean estado,Professor professor,Horario horario,int duracao,double precohora){
        super(estado, professor, horario, duracao);
        this.precohora=precohora;
    }

    /**
     * Método para obter o preço por hora da aula individual
     * @return Preço por hora da aula individual
     */
    public double getPrecohora() {
        return this.precohora;
    }

    /**
     * Método para definir o preço por hora da aula individual
     * @param precohora Preço por hora da aula individual
     */

    public void setPrecohora(double precohora) {
        this.precohora = precohora;
    }

    /**
     * Método para imprimir somente a informação da aula individual com um custo superior a 20 euros
     */

    @Override
    public int informacao(){
        if ((this.getPrecohora() * (this.getDuracao() / 60.0)) > 20) {
            System.out.println(this);
            return 1;
        }
        return 0;
    }

    /**
     * Método para identificar a classe
     * @return 1
     */
    @Override
    public int identificacao(){
        return 1;
    }

    /**
     * Método toString:
     * Imprime a informação da aula individual no ecrã
     * @return Professor + Horário + Duração + Estado + Preço por hora
     */
    @Override
    public String toString(){
        return "\n-----AULA INDIVIDUAL-----\n" + super.toString()+ "\nPreço por hora: " + this.getPrecohora()+ " euro(s).\n";
    }
}
