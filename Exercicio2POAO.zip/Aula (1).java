/**
 * @author Alexandre Ferreira
 * @version 1.0
 */

/**
 * Classe para definir uma aula
 */
abstract class Aula {
    /**
     * Estado da aula (cancelada ou não)
     */
    protected boolean estado;
    /**
     * Professor da aula
     */
    protected Professor professor;
    /**
     * Horário de início da aula
     */
    protected Horario horario;
    /**
     * Duração da aula
     */
    protected int duracao;

    /**
     * Construtor sem parâmetros
     */
    public Aula(){}

    /**
     * Construtor da classe, recebe dados para a inicialização dos atributos
     * @param estado Estado da aula (cancelada ou não)
     * @param professor Professor da aula
     * @param horario Horário de início da aula
     * @param duracao Duração da aula
     */

    public Aula(boolean estado, Professor professor, Horario horario, int duracao) {
        this.estado = estado;
        this.professor = professor;
        this.horario = horario;
        this.duracao = duracao;
    }

    /**
     * Método para obter o estado da aula
     * @return Estado da aula
     */
    public boolean getEstado() {
        return this.estado;
    }

    /**
     * Método para definir o estado da aula
     * @param estado Estado da aula
     */

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    /**
     * Método para obter o horário de início da aula
     * @return Horário de início da aula
     */
    public Horario getHorario() {
        return horario;
    }

    /**
     * Método para definir o horário de início da aula
     * @param horario Horário de início da aula
     */
    public void setHorario(Horario horario) {
        this.horario = horario;
    }

    /**
     * Método para obter o professor da aula
     * @return Professor da aula
     */
    public Professor getProfessor() {
        return professor;
    }

    /**
     * Método para definir o professor da aula
     * @param professor Professor da aula
     */
    public void setProfessor(Professor professor) {
        this.professor = professor;
    }

    /**
     * Método para obter a duração da aula
     * @return Duração
     */
    public int getDuracao() {
        return this.duracao;
    }

    /**
     * Método para definir a duração da aula
     * @param duracao Duração
     */

    public void setDuracao(int duracao) {
        this.duracao = duracao;
    }

    /**
     * Método abstrato para garantir polimorfismo
     */

    public abstract int informacao();

    /**
     * Método abstrato para garantir polimorfismo
     * @return Sem return
     */
    public abstract int identificacao();

    /**
     * Método toString:
     * Imprime a informação da aula no ecrã
     * @return Professor + Horário + Duração + Estado
     */

    @Override
    public String toString() {
        if (this.getEstado()) {
            return "\nProfessor: " + this.getProfessor().toString() + "\nHorário: " + this.getHorario().toString() + "\nDuração: " + this.getDuracao() + " minutos" + "\nEstado: marcada";
        } else {
            return "\nProfessor: " + this.getProfessor().toString() + "\nHorário: " + this.getHorario().toString() + "\nDuração: " + this.getDuracao() + " minutos" + "\nEstado: cancelada";
        }
    }
}
