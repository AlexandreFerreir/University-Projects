/**
 * @author Alexandre Ferreira
 * @version 1.0
 */

/**
 * Subclasse da classe aula para definir uma aula de grupo
 */
class AulasdeGrupo extends Aula {
    /**
     * Modalidade da aula de grupo
     */
    protected String modalidade;
    /**
     * Número máximo de alunos da aula de grupo
     */
    protected int maximoalunos;

    /**
     * Construtor sem parâmetros
     */
    public AulasdeGrupo(){}

    /**
     * Construtor da subclasse, recebe dados para a inicialização dos atributos da superclasse e subclasse
     * @param estado Estado da aula de grupo
     * @param professor Professor da aula de grupo
     * @param horario Horário da aula de grupo
     * @param duracao Duração da aula de grupo
     * @param modalidade Modalidade da aula de grupo
     * @param maximoalunos Número máximo de alunos da aula de grupo
     */
    public AulasdeGrupo(boolean estado,Professor professor,Horario horario,int duracao,String modalidade,int maximoalunos){
        super(estado, professor, horario, duracao);
        this.modalidade=modalidade;
        this.maximoalunos=maximoalunos;
    }

    /**
     * Método para obter a modalidade da aula de grupo
     * @return Modalidade da aula de grupo
     */
    public String getModalidade() {
        return modalidade;
    }

    /**
     * Método para definir a modalidade da aula de grupo
     * @param modalidade Modalidade da aula de grupo
     */

    public void setModalidade(String modalidade) {
        this.modalidade = modalidade;
    }

    /**
     * Método para obter o número máximo de alunos da aula de grupo
     * @return Número máximo de alunos da aula de grupo
     */
    public int getMaximoalunos() {
        return maximoalunos;
    }

    /**
     * Método para definir o número máximo de alunos da aula de grupo
     * @param maximoalunos Número máximo de alunos da aula de grupo
     */


    public void setMaximoalunos(int maximoalunos) {
        this.maximoalunos = maximoalunos;
    }

    /**
     * Método para imprimir somente a modalidade e horário da aula de grupo com número máximo de alunos inferior a 10
     */
    @Override
    public int informacao(){
        if (this.getMaximoalunos()< 10){
            System.out.println("\n-----AULA DE GRUPO-----\nModalidade da aula de grupo: " + this.getModalidade() + "\nHorário: "+ this.getHorario().toString());
            return 1;
        }
        return 0;
    }

    /**
     * Método para identificar a classe
     * @return 0
     */
    @Override
    public int identificacao(){
        return 0;
    }
    /**
     * Método toString:
     * Imprime a informação da aula de grupo no ecrã
     * @return Professor + Horário + Duração + Estado + Modalidade + Número máximo de alunos
     */
    @Override
    public String toString(){
        return "\n-----AULA DE GRUPO-----\n" + super.toString() + "\nModalidade: " + this.getModalidade() + " \nNúmero máximo de alunos: "+ this.getMaximoalunos()+ "\n";
    }
}
